#pragma once
#include <json.hpp>
#include <optional>
namespace leagueapi {
  struct LolChampSelectChampSelectMySelection_t {
    std::optional<int32_t> selectedSkinId;
    std::optional<int64_t> wardSkinId;
    std::optional<uint64_t> spell1Id;
    std::optional<uint64_t> spell2Id;
  };

  inline void to_json(nlohmann::json& j, const LolChampSelectChampSelectMySelection_t& v) {
    if(v.selectedSkinId)
      j["selectedSkinId"] = *v.selectedSkinId;
    if(v.wardSkinId)
      j["wardSkinId"] = *v.wardSkinId;
    if(v.spell1Id)
      j["spell1Id"] = *v.spell1Id;
    if(v.spell2Id)
      j["spell2Id"] = *v.spell2Id;
  }

  inline void from_json(const nlohmann::json& j, LolChampSelectChampSelectMySelection_t& v) {
    if(auto it = j.find("selectedSkinId"); it != j.end() !it->is_null())
      v.selectedSkinId = it->get<int32_t>();
    if(auto it = j.find("wardSkinId"); it != j.end() !it->is_null())
      v.wardSkinId = it->get<int64_t>();
    if(auto it = j.find("spell1Id"); it != j.end() !it->is_null())
      v.spell1Id = it->get<uint64_t>();
    if(auto it = j.find("spell2Id"); it != j.end() !it->is_null())
      v.spell2Id = it->get<uint64_t>();
  }
}
