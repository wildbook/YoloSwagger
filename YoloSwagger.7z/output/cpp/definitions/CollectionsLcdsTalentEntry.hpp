#pragma once
#include <json.hpp>
#include <optional>
namespace leagueapi {
  struct CollectionsLcdsTalentEntry_t {
    int32_t talentId;
    int32_t rank;
  };

  inline void to_json(nlohmann::json& j, const CollectionsLcdsTalentEntry_t& v) {
    j["talentId"] = v.talentId;
    j["rank"] = v.rank;
  }

  inline void from_json(const nlohmann::json& j, CollectionsLcdsTalentEntry_t& v) {
    v.talentId = j.at("talentId").get<int32_t>();
    v.rank = j.at("rank").get<int32_t>();
  }
}
